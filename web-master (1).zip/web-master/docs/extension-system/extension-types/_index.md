---
title: "Extension Types"
date: 2024-01-25T00:00:00+00:00
weight: 50
geekdocRepo: https://github.com/owncloud/web
geekdocEditPath: edit/master/docs/extension-system
geekdocFilePath: _index.md
geekdocCollapseSection: true
---

This section is a guide about the different predefined extension types of ownCloud Web. Please refer to the respective 
subpages to learn more about the individual extension types.
