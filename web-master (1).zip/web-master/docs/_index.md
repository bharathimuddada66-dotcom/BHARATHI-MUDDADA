---
title: "ownCloud Web"
date: 2018-05-02T00:00:00+00:00
weight: -15
geekdocRepo: https://github.com/owncloud/web
geekdocEditPath: edit/master/docs
geekdocFilePath: _index.md
geekdocCollapseSection: true
---

This is the next generation ownCloud frontend. 
If you're new here, head over to the the [getting started guide]({{< ref "getting-started.md" >}}) for a quick introduction.
