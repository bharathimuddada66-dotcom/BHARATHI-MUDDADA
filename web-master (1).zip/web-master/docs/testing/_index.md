---
title: "Tests"
date: 2022-01-28T00:00:00+00:00
weight: 55
geekdocRepo: https://github.com/owncloud/web
geekdocEditPath: edit/master/docs/testing
geekdocFilePath: _index.md
geekdocCollapseSection: true
---

Guides on running different kinds of tests in ownCloud Web.
