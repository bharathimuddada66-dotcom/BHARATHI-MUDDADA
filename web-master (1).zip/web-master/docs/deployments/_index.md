---
title: "Deployments"
date: 2018-05-02T00:00:00+00:00
weight: 55
geekdocRepo: https://github.com/owncloud/web
geekdocEditPath: edit/master/docs/deployments
geekdocFilePath: _index.md
geekdocCollapseSection: true
---

Showcases of different scenarios of deploying ownCloud Web.
