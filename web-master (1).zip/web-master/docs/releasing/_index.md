---
title: 'Releasing'
date: 2025-06-16T00:00:00+00:00
weight: 50
geekdocRepo: https://github.com/owncloud/web
geekdocEditPath: edit/master/docs/releasing
geekdocFilePath: _index.md
geekdocCollapseSection: true
---

{{< toc >}}

This section serves as a guide for releasing ownCloud Web and managing important deprecations for a release.
