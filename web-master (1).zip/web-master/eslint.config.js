import owncloudersConfig from '@ownclouders/eslint-config'

export default [...owncloudersConfig]
