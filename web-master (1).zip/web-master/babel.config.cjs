module.exports = {
  presets: ['@ownclouders/babel-preset']
}
