export const APPID = 'activities'
