export const supportedLogoMimeTypes = ['image/gif', 'image/jpeg', 'image/png']
export const perPageDefault = '50'
export const perPageStoragePrefix = 'admin-settings'
export const paginationOptions = ['20', '50', '100', '250']
