<template>
  <tbody>
    <slot />
  </tbody>
</template>
<script lang="ts" setup>
defineOptions({
  name: 'OcTbody',
  status: 'ready',
  release: '2.1.0'
})
</script>
