<template>
  <tfoot>
    <slot />
  </tfoot>
</template>
<script lang="ts" setup>
defineOptions({
  name: 'OcTfoot',
  status: 'ready',
  release: '2.1.0'
})
</script>
