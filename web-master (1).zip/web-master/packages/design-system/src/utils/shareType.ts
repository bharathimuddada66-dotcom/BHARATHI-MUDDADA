/**
 * Share type
 */
export const shareType = {
  user: 0,
  group: 1,
  link: 3,
  guest: 4,
  remote: 6
}
