const __logger = (v: unknown) => v

export default __logger
