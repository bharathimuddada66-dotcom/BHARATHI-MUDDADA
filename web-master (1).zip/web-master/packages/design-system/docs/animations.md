## How to use animations
To see how to use animations, please follow [transitions section of Vue.js documentation](https://vuejs.org/v2/guide/transitions.html). As a name of the transition, it is possible to use any of the following animations.

## Available animations
| Name           | Description | Usage       |
| -------------- | ----------- | ----------- |
| fadeIn         | The element fades in from the left  | `.oc-fade-in` |
