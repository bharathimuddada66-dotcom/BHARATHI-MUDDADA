# ownCloud Design System

**ownCloud Design System** is based on [Vue Design System](https://vueds.com/) - **Thanks a lot to [@viljamis](https://twitter.com/viljamis)**

Head over to the [generated docs](https://owncloud.github.io/owncloud-design-system/) for more information!
