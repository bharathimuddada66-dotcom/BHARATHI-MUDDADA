Bugfix: Enable external shares editing

We've reenabled external shares editing. It was previously disabled due to missing implementation of OCM shares editing in the backend. That has been implemented in the meantime.

https://github.com/owncloud/web/pull/12204
https://github.com/owncloud/web/issues/12201
