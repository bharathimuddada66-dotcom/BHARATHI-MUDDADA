Enhancement: Add password protected folders app

We've added a new application called "Password protected folders". This application allows users to create new folders that are accessible only by entering a password.

https://github.com/owncloud/web/pull/12137
https://github.com/owncloud/web/issues/12039
