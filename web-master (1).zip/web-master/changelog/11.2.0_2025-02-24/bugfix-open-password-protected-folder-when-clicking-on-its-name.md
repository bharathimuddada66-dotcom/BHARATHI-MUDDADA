Bugfix: Open password protected folder when clicking on its name

We've fixed an issue where clicking on the password protected folder name in the list did not do anything. Clicking on the name name will open the folder.

https://github.com/owncloud/web/pull/12177
https://github.com/owncloud/web/issues/12176
