Bugfix: Create password protected folder in personal space

We've fixed an issue where the password protected folder was created in current space instead of users personal space.

https://github.com/owncloud/web/pull/12146
https://github.com/owncloud/web/issues/12039
