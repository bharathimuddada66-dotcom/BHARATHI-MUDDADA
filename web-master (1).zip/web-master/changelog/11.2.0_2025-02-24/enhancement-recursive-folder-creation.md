Enhancement: Recursive folder creation

We've extended the `CreateFolderFactory` in web-client to allow creating folders recursively. Simply pass `recursive: true` into options and all parent folders will be created.

https://github.com/owncloud/web/pull/12146
