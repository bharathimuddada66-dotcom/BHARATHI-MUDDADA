Bugfix: Sanitize content from md-editor-v3

We've fixed an issue where the user can inject XSS attack by sanitizing the user's content

https://github.com/owncloud/web/pull/12195
https://github.com/owncloud/enterprise/issues/7092
