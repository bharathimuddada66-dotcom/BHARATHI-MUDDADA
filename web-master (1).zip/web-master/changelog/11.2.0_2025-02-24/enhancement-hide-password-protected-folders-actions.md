Enhancement: Hide password protected folders action

We've hidden all actions on password protected folders except delete.

https://github.com/owncloud/web/pull/12145
https://github.com/owncloud/web/issues/12039
