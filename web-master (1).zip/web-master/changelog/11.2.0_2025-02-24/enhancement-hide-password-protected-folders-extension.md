Enhancement: Hide password protected folders extension

We've hidden the password protected folder ".psec" extension.

https://github.com/owncloud/web/pull/12145
https://github.com/owncloud/web/issues/12039
