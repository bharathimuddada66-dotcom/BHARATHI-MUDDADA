Enhancement: Delete password protected folders

We've extended the delete resources handler to also delete the hidden folder acting as the password protected folder when deleting a `.psec` files.

https://github.com/owncloud/web/pull/12152
https://github.com/owncloud/web/issues/12039
