Enhancement: Add password protected folders handler

We've added a new file action used to handle password protected folders. When a password protected folder is opened, a popup is opened prompting the user to enter the password. After successfully entering the password, content of the folder is displayed inside of the popup.

https://github.com/owncloud/web/pull/12142
https://github.com/owncloud/web/issues/12039
