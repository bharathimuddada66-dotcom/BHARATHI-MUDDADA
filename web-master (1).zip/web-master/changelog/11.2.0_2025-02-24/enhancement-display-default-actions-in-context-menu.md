Enhancement: Display default actions in context menu

We've added default actions into the context menu so that the user can use that action when accessing the resource through it.

https://github.com/owncloud/web/pull/12145
https://github.com/owncloud/web/issues/12039
