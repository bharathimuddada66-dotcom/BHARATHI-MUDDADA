Enhancement: Password protected folder permissions

We've added the permissions dropdown into the create password protected folder dialog. Users can now decide what permissions they would like to add to the folder. Permissions are matching folder public link permissions.

https://github.com/owncloud/web/pull/12141
https://github.com/owncloud/web/issues/12039
