Bugfix: Export correct design system files

We've fixed the export of the design system files to ensure they are correctly exported as ES modules.

https://github.com/owncloud/web/pull/12717
