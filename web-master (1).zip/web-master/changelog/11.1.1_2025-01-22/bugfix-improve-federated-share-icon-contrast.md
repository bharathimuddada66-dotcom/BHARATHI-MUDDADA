Bugfix: Improve federated share icon contrast

We've made the color of the federated share icon slightly lighter in order to have a sufficient contrast compared to the icon background.

https://github.com/owncloud/web/pull/12118
https://github.com/owncloud/web/issues/12117
