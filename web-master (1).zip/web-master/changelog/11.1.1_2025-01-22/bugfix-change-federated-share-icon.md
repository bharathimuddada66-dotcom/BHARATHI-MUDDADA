Bugfix: Change federated share icon

We've changed the icon we are using for federated shares in the Shared with others list from "cloud" into "earth".

https://github.com/owncloud/web/pull/12118
https://github.com/owncloud/web/issues/12117
