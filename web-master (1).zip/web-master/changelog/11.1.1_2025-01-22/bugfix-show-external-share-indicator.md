Bugfix: Show external share indicator

We've fixed the condition that was preventing the external share indicator from showing up when a permissions indicator was visible.

https://github.com/owncloud/web/pull/12119
https://github.com/owncloud/web/issues/12117
