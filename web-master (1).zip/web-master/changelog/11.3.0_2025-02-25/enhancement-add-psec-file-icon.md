Enhancement: Add psec file icon

We've added a new icon which will be used for psec files. These files are representing our password protected folders.

https://github.com/owncloud/web/pull/12104
