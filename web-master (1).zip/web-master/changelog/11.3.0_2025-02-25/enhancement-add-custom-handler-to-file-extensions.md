Enhancement: Add custom handler to file extensions

We've added a new property into application file extensions called `customHandler`. This property allows app developers to use completely custom flows when creating new files.

https://github.com/owncloud/web/pull/12109
