Enhancement: Handle extensions without editor

We've added a new property to extensions that asserts whether is has an editor or not. This property is computed by checking whether the extension exposes any routes.

https://github.com/owncloud/web/pull/12105
