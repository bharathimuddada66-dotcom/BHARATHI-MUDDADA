Bugfix: Rename ScienceMesh

We've renamed ScienceMesh in German locale to prevent confusion among non-science community.

https://github.com/owncloud/ocis/issues/10891
