Bugfix: mock services correctly in test file

We've mocked the clientservice correctly in the test file.

https://github.com/owncloud/web/pull/12377
https://github.com/owncloud/web/issues/12375
