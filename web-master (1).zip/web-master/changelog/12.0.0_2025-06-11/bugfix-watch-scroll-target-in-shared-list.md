Bugfix: Watch scroll target in shared list

Inside of shared with me list, watch for changes of the scroll target so that we can react and scroll to the resource when user clicks on a notification while being already in the list.

https://github.com/owncloud/web/pull/12385
https://github.com/owncloud/web/issues/10398
