Enhancement: Add Catalan to list of supported languages

We have added Catalan to the list of supported languages.

https://github.com/owncloud/web/pull/12578
https://github.com/owncloud/web/issues/11299
