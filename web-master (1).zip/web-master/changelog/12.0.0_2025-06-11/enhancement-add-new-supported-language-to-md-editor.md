Enhancement: add new supported language to md-editor

We've updated the md-editor extension to the latest version which supports Arabic language. We have also added auto focus on the editor.

https://github.com/owncloud/web/pull/12243
