Bugfix: sorting arrow misplaced

We've fixed an issue where sorting arrow is showed below the text instead of next to it.

https://github.com/owncloud/web/pull/12236
https://github.com/owncloud/web/issues/12232
