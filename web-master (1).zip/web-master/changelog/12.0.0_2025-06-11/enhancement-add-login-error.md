Enhancement: Add login error

When the login fails due to any kind of error, the user is now presented with an error message.

https://github.com/owncloud/web/pull/12648
