Change: Remove deprecated type prop

We have removed the deprecated type prop from the ApplicationInformation type.

https://github.com/owncloud/web/pull/12686
https://github.com/owncloud/web/issues/7338
https://github.com/owncloud/web/commit/5e8ac918de780f0b03ad79a85b8c25e4ba1fe4df
