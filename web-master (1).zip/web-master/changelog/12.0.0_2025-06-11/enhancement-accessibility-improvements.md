Enhancement: Accessibility improvements

We have further improved accessibility aspects of the web UI.

https://github.com/owncloud/web/issues/5379
https://github.com/owncloud/web/issues/5381
https://github.com/owncloud/web/pull/10830
