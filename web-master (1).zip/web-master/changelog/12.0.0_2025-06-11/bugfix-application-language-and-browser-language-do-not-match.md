Bugfix: Application language and browser language do not match

We've added a fix to ensure that the application language and browser language match. This fix is particularly important for users who have set their browser language to a language that is not supported by us.


https://github.com/owncloud/web/pull/12487
https://github.com/owncloud/web/issues/12486
