Enhancement: Add loading spinner to submit button

We have enhanced the user experience by displaying a loading spinner and disabling the submit button when clicked on password-protected public links. This ensures users on slower connections receive clear feedback that their request is being processed.

https://github.com/owncloud/web/pull/12513
https://github.com/owncloud/enterprise/issues/7190
