Change: Remove deprecated client init method

We have removed the deprecated client init method.
Use `graph()`, `ocs()` and `webdav()` to initialize and use clients (https://github.com/owncloud/web/pull/11656).

https://github.com/owncloud/web/pull/12686
https://github.com/owncloud/web/issues/7338
