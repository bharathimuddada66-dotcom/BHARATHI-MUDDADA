Enhancement: Create spaces via admin settings

We've added a new feature that allows you to create spaces via the admin settings.

https://github.com/owncloud/web/pull/11849
https://github.com/owncloud/web/issues/11771