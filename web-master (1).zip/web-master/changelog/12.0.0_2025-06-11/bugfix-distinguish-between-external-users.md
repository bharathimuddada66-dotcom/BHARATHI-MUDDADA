Bugfix: add domain to distinguish between external users

We've fixed an issue where multiple external users with the same name were indistinguishable. By adding the domain to the user information/tooltip and below the user name, external users can now be easily distinguished.

https://github.com/owncloud/web/pull/12339
https://github.com/owncloud/web/issues/12184
