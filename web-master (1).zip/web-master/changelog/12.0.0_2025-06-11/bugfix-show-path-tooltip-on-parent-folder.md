Bugfix: Show path tooltip on parent folder

Instead of displaying tooltip with resource path while hovering/focusing on the resource, display it on parent folder with parent folder path.

https://github.com/owncloud/web/pull/12356
https://github.com/owncloud/web/issues/7776
