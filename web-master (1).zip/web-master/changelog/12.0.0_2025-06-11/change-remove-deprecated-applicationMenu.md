Change: Remove deprecated applicationMenu

We have removed the deprecated applicationMenu property from the ApplicationInformation type.
Register app menu items via the appMenuExtensionPoint instead (https://github.com/owncloud/web/pull/11258).

https://github.com/owncloud/web/pull/12686
https://github.com/owncloud/web/issues/7338
