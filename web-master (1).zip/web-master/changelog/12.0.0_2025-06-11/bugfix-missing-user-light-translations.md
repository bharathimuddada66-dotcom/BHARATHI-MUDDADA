Bugfix: Missing User Light translations

We've added a missing "User Light" string definition into our translations in order to get this role translated.

https://github.com/owncloud/web/pull/12101
https://github.com/owncloud/web/issues/12100
