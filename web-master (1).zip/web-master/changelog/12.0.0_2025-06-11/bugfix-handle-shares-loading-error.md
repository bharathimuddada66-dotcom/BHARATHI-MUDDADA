Bugfix: Handle shares loading error

Display error message instead of showing the loader infinitely when we encounter an error during shares or space members loading.

https://github.com/owncloud/web/pull/12336
https://github.com/owncloud/ocis/issues/11119