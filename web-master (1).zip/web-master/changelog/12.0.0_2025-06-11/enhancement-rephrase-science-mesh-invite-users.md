Enhancement: rephrase invite users to invite users to federate

We have rephrase science mesh "invite users" to "invite users to federate" to make it clearer to the users.

https://github.com/owncloud/web/pull/12355
https://github.com/owncloud/web/issues/11566
