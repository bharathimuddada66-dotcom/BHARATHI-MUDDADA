Change: Remove deprecated isFileEditor

We have removed the deprecated isFileEditor property from the ApplicationInformation type.

https://github.com/owncloud/web/pull/12686
https://github.com/owncloud/web/issues/7338
https://github.com/owncloud/web/commit/67ce21ce1bcc449d18f53e4930d180198a19faa0
