Change: Remove deprecated ApplicationQuickAction

We have removed the deprecated ApplicationQuickAction type.
Register quick actions as extension instead (https://github.com/owncloud/web/pull/10102).

https://github.com/owncloud/web/pull/12686
https://github.com/owncloud/web/issues/7338
