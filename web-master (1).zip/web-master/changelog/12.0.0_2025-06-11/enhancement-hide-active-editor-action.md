Enhancement: Hide active editor action

We've hidden the sidebar file action of a currently opened editor. This prevents confusion where user might try to re-open the current editor.

https://github.com/owncloud/web/pull/12110
https://github.com/owncloud/web/issues/12108
