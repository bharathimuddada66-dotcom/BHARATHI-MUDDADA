Enhancement: Add flat list view 

We've added a new flat list view. This feature provides a flat view of files and folders, allowing users to sort them in ascending or descending order without grouping folders separately from files.

https://github.com/owncloud/web/pull/12509
https://github.com/owncloud/web/issues/12503
