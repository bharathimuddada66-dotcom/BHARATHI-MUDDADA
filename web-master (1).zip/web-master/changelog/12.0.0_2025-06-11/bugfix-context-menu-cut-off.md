Bugfix: space context menu is cropped with limited vertical screen space

We've fixed the issue of context menu being cut off when vertical screen space is limited.

https://github.com/owncloud/web/pull/12368
https://github.com/owncloud/web/issues/11205
