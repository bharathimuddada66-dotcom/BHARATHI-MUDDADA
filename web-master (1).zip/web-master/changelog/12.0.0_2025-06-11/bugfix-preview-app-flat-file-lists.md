Bugfix: Preview app flat file lists

We've fixed the image loading of the preview app in flat file lists ("Shared with me", "Shared with others", "Shared via link", favorites, search result page) so all images of the current file list are being loaded.

https://github.com/owncloud/web/pull/11960
https://github.com/owncloud/web/issues/8932
