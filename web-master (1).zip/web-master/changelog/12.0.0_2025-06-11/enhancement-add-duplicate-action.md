Enhancement: Add duplicate action

We've added a new resource action that can be used to duplicate resources. The action is available in the app bar of files app, resource context menu, and the resource actions panel in the sidebar. The action can be used on a single or multiple resources. Triggering the action will start a worker that will duplicate the resources into the same folder and space.

https://github.com/owncloud/web/pull/12508
https://github.com/owncloud/web/issues/9898
