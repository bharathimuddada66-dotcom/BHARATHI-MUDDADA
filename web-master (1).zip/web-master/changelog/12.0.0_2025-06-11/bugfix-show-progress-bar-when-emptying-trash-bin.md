Bugfix: Show progress bar when emptying trash bin

We've fixed a bug where the progress bar wasn't shown when emptying the trash bin.

https://github.com/owncloud/web/pull/11967
https://github.com/owncloud/web/issues/11966