Bugfix: Use resource ID in share notifications

When building a link to a resource in shared with me notifications, we now use the resource ID instead of share ID to correctly navigate and scroll to the resource.

https://github.com/owncloud/web/pull/12385
https://github.com/owncloud/web/issues/10398
