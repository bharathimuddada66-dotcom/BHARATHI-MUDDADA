Enhancement: Improve file drop view UI

We've added an explanatory note to the file drop view to help users understand the purpose of the view. We also added more branding elements and we made the upload action more prominent by adding a dedicated button to start the upload.

https://github.com/owncloud/web/pull/12519
