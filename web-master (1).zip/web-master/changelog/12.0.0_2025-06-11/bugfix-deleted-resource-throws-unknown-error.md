Bugfix: Delete resource throws unknown error

We've added a friendly error message when user tries to open a resource that has been deleted.

https://github.com/owncloud/web/pull/12482
https://github.com/owncloud/web/issues/11014

