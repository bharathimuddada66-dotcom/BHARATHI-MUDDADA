Bugfix: Fix wrong HTML lang attribute

We've added a fix to ensure that the HTML lang attribute is set correctly in the web application. This change improves accessibility and ensures that screen readers and other assistive technologies can properly interpret the language of the content.

https://github.com/owncloud/web/pull/12478
https://github.com/owncloud/web/issues/12409
