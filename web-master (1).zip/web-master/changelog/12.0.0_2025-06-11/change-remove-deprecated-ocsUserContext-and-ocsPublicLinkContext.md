Change: Remove deprecated ocsUserContext and ocsPublicLinkContext

We have removed the deprecated ocsUserContext and ocsPublicLinkContext properties from the ClientService.
Use `ocs` instead (https://github.com/owncloud/web/pull/11656).

https://github.com/owncloud/web/pull/12686
https://github.com/owncloud/web/issues/7338
