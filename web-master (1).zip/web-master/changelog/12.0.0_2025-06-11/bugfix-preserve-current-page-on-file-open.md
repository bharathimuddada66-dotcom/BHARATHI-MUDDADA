Bugfix: preserve current page when opening a file

Add page query into meta contextQueryItems in the route definition

https://github.com/owncloud/web/pull/12207
https://github.com/owncloud/web/issues/12162
