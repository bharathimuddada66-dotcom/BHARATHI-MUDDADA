Change: Remove CERN's collapsible table

We have removed the CERN's collapsible table component. Resource table will now always use the regular `oc-table` component. The collapsible table is replaced by filtering functionality in the shares page.

https://github.com/owncloud/web/pull/12567
