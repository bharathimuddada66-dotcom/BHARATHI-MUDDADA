Bugfix: Add missing label to rename button

Set `aria-label` to the rename button in the resource table for folders and files.

https://github.com/owncloud/web/pull/12646
