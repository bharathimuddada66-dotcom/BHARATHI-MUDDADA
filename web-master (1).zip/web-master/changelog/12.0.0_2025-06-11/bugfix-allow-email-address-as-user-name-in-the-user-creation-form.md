Bugfix: Allow email address as user name in the user creation form

We've fixed user name filtering in the user creation form to allow entering email address as user name, thus aligning UI filtering with backend filtering.

https://github.com/owncloud/web/issues/12228
https://github.com/owncloud/web/pull/12229
