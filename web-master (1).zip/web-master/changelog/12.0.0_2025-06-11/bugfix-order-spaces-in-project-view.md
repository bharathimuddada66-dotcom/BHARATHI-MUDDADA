Bugfix: Fix sorting in spaces view that may crash the application

Fixed a bug where the project/spaces view crashed when orderd by quota items.

https://github.com/owncloud/web/pull/12351
