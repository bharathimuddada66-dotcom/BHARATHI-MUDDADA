Enhancement: Disable space membership management when it's server-managed

Hide the "Add members" section and member edit options in the "Members" panel in the space sidebar when the `spaces.server_managed` capability is `true`.

https://github.com/owncloud/web/pull/12584
