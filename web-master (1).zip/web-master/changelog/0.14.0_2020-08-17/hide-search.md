Change: Provide option for hiding the search bar

We introduced a new `options.hideSearchBar` config variable which can be used to disable the search bar entirely.

https://github.com/owncloud/product/issues/116
https://github.com/owncloud/web/pull/3817
