Change: Large file downloads support with URL signing

When the backend supports URL signing we now download with a signed url instead of downloading as BLOB.

https://github.com/owncloud/web/pull/3797
