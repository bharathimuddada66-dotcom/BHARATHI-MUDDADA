Change: Adapt to new ocis-settings data model

ocis-settings introduced UUIDs and less verbose endpoint and message type names. This PR adjusts web accordingly.

https://github.com/owncloud/web/pull/3806
https://github.com/owncloud/owncloud-sdk/pull/520
https://github.com/owncloud/ocis-settings/pull/46
