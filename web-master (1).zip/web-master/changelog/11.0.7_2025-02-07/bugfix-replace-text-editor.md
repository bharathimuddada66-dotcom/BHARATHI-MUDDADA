Bugfix: replace text editor

We've added a new text editor because of security issues with the previous editor and lack of support.

https://github.com/owncloud/web/pull/12156
https://github.com/owncloud/enterprise/issues/7077
