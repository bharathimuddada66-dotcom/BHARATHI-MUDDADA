Bugfix: Drop advanced mode when creating links

We've removed the advanced mode in the create public link dialog and we show the password and expiration date fields directly.

https://github.com/owncloud/web/pull/12326
https://github.com/owncloud/web/issues/12275