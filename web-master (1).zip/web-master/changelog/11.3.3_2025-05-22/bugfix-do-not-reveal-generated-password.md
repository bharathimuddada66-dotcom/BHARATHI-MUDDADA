Bugfix: Do not reveal generated password

We've stopped revealing passwords in the password input when user clicks on the generate action. In order to preview the password, the user needs to click on the eye icon inside the input.

https://github.com/owncloud/web/pull/12326
https://github.com/owncloud/web/issues/12275