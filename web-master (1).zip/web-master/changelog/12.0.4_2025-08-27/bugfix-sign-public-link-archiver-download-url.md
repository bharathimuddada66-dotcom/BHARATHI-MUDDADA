Bugfix: Sign public link archiver download URL

We've started signing the archiver download URL in public link context in case the link is password protected.
This allows users to download large archives without memory limits imposed by browsers.

https://github.com/owncloud/web/pull/12943
https://github.com/owncloud/web/issues/12811
