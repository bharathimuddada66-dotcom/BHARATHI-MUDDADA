Bugfix: Add missing dependencies to markdown editor

Due to several missing dependencies of the markdown editor app, some features were not fully working or were throwing an error. We added the following dependencies:

- highlight.js
- mermaid
- screenfull
- katex

https://github.com/owncloud/web/pull/12460
