Bugfix: Hide save in markdown editor

We hid the save button in the markdown editor as it was not functional. We decided on hiding it as it could be confusing with already having a save button provided by the app container.

https://github.com/owncloud/web/pull/12460
