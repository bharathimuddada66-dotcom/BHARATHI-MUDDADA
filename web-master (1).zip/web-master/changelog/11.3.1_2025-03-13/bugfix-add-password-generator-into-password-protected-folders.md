Bugfix: Add password generator into password protected folders

We've added a password generator into the password protected folders modal. This allows users to generate a new password if they want to.

https://github.com/owncloud/web/pull/12270
