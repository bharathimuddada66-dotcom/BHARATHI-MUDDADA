Bugfix: Disable password protected folders creation inside public links

We've disabled the option to create password protected folders creation inside of folders that are shared via a public link.

https://github.com/owncloud/web/pull/12226
https://github.com/owncloud/web/issues/12190
