Bugfix: broken title for public files link

We've fixed the issue of showing an incorrect/broken window title when user opens a public files link

https://github.com/owncloud/web/pull/12225
https://github.com/owncloud/web/issues/12220
