Enhancement: Display custom attributes in share autocomplete

When sharing a resource, we're now displaying custom attributes in the autocomplete.
Previously, we were only displaying the user's email address.
What attributes are displayed depends on the server configuration.

https://github.com/owncloud/web/pull/13144
