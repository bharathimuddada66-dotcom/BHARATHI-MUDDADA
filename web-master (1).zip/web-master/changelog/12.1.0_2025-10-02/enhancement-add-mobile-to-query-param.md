Enhancement: Add mobile to query param

In order to enable ONLYOFFICE Mobile Web View, we have added the `mobile` query parameter to the document editor URL. This allows users to access a mobile-optimized version of the document editor when accessing it from mobile devices.

https://kiteworks.atlassian.net/browse/OCISDEV-305
https://github.com/owncloud/web/pull/13110
