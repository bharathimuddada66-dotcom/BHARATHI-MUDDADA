Enhancement: Replace board icon

We've replaced the GeoGebra board icon with a new one.
The new icon no longer includes the "beta" badge.

https://github.com/owncloud/web/pull/12974
