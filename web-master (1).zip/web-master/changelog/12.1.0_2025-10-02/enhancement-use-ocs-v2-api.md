Enhancement: Use OCS v2 API

We have updated the OCS API to version 2. This is not a breaking change because oCIS uses one implementation for both versions.

https://github.com/owncloud/web/pull/13111
