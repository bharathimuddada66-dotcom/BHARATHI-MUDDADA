Enhancement: Use switch for full text search filter

We've replaced the "Title only" search filter pill with a toggle between "Title Only" and "Full Text Search".
This change should improve the user experience as it's easier to understand the toggle.

https://github.com/owncloud/web/pull/12915
