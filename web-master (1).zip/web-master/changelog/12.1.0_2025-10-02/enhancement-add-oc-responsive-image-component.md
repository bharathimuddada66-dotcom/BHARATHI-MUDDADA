Enhancement: Add OcResponsiveImage component

We've added a new component to display an image which will change its source based on the viewport width.

https://github.com/owncloud/web/pull/13093
