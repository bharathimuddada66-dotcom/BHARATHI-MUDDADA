Enhancement: Add MFA capability

We've added a capability to check if MFA is enabled.
If the capability is enabled, we will require MFA when accessing the admin settings page.

https://github.com/owncloud/web/pull/12925
