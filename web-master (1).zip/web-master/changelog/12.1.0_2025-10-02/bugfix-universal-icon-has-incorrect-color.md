Bugfix: Use correct color for universal icon

We've fixed the universal icon color to ensure it matches the chosen theme.

https://kiteworks.atlassian.net/browse/OCISDEV-353
https://github.com/owncloud/web/pull/13142
