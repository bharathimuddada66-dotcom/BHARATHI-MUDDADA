Enhancement: Add GeoGebra pinboard icon

We've added a new icon for GeoGebra pinboards.

https://github.com/owncloud/web/pull/12973
