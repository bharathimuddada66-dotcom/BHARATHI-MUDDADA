Bugfix: Add clipboard permissions

We've added clipboard permissions to the iframe in external apps to allow the external editor to read and write to the clipboard.

https://github.com/owncloud/web/pull/12954
