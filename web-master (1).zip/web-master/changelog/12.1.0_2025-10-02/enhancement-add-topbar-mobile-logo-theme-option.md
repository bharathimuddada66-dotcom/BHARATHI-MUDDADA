Enhancement: Add topbar mobile logo theme option

We've added a new theme option called `logo.topbarSm` to set a different logo for the topbar on mobile devices.

https://github.com/owncloud/web/pull/13093
