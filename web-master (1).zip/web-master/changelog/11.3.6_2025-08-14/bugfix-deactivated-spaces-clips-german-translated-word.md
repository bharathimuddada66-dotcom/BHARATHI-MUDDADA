Bugfix: Deactivated Space button clips German translated word

We have fixed an issue where the "Deactivated Space" button would clip the German translated word. The button now displays the full word without clipping.

https://kiteworks.atlassian.net/browse/OCISDEV-194
https://github.com/owncloud/web/pull/12890
