Bugfix: user info getting translated

We have fixed the issue where user's info are getting translated by disabling browser translation for certain fields, avatar image, first name, last name and username.

https://kiteworks.atlassian.net/browse/OCISDEV-193
https://github.com/owncloud/web/pull/12893
