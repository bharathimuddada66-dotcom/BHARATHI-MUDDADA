Bugfix: Md Text Html Preview Text gets Clipped

We've fixed an issue where the first letter of a text was clipped during HTML
preview rendering due to improper margin

https://github.com/owncloud/web/pull/12697
https://github.com/owncloud/enterprise/issues/7233
