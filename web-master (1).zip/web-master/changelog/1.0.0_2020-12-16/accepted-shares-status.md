Enhancement: show status of accepted shares

The status column of accepted shares was blank.

https://github.com/owncloud/ocis/issues/985
