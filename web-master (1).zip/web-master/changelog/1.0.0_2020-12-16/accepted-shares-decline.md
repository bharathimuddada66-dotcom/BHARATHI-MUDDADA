Enhancement: add the option to decline accepted shares

Declined shares could be accepted retroactively but accepted shares could not be declined.

https://github.com/owncloud/ocis/issues/985

