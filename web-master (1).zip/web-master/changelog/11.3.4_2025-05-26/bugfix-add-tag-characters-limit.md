Bugfix: Add tag characters limit

We now limit the number of characters in a tag. The limit is configured in the capabilities and defaults to 30.

https://github.com/owncloud/web/pull/12474