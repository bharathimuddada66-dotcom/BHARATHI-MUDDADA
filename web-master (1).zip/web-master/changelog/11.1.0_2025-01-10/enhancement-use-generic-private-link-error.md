Enhancement: Use generic private link error

We've added a more generic error message to the unavailable private links as the previous message was confusing.

https://github.com/owncloud/web/pull/12054
https://github.com/owncloud/web/issues/12009
