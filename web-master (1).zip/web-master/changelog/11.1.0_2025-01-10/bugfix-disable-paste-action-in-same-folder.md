Bugfix: Disable paste action in same folder

We've fixed the state of the "paste files" action when copied resources are from the same folder. The button will be disabled in such case and a tooltip with explanation message displayed.

https://github.com/owncloud/web/pull/12044
https://github.com/owncloud/web/issues/12021
