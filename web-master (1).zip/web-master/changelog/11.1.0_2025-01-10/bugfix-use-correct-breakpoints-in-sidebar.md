Bugfix: Use correct breakpoints in sidebar

We've set the correct breakpoint used for setting width of the sidebar so that it matches the breakpoint in app wrapper.

https://github.com/owncloud/web/pull/12045
