Bugfix: Change opacity of disabled checkboxes

We've fixed an issue where disabled checkbox was not clearly distinguishable from enabled ones by lowering it's opacity.

https://github.com/owncloud/web/pull/12063
https://github.com/owncloud/web/issues/12060
