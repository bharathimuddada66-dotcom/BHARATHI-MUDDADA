Bugfix: Show indirect shares on search page

We've fixed an issue where the indirect shares of resources were not displayed in the sidebar when user is on search page.

https://github.com/owncloud/web/pull/12050
https://github.com/owncloud/web/issues/10939
