Enhancement: Add Visio file icons

Added a new file icon for Visio files. The icon is used for files with the extension `.vsd`, `.vsdm`, `.vsdx`, `.vss`, `.vssm`, `.vssx`, `.vst`, `.vstm`, `.vstx`.
The icon is a `file` icon from Font Awesome adjusted by subtracting the `project-diagram` icon from it.

https://fontawesome.com/v5/icons/file?f=classic&s=solid
https://fontawesome.com/v5/icons/project-diagram?f=classic&s=solid
https://github.com/owncloud/web/pull/13197
