Bugfix: Remove duplicate resource links

In the resources table, we had duplicate resource links. This has been fixed by removing the link from the resource icon.
The icon is now treated solely as a decorative element and is hidden from screen readers.

https://github.com/owncloud/web/pull/13203
