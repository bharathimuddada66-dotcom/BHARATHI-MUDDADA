Enhancement: Add Excalidraw file icon

Added a new file icon for Excalidraw files. Any file with the extension `.excalidraw` will now have the Excalidraw logo as file icon.

https://github.com/owncloud/web/pull/13172
