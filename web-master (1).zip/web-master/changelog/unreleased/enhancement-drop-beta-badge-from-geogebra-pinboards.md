Enhancement: Drop beta badge from GeoGebra pinboards

We've dropped the beta badge from the GeoGebra pinboard icon.

https://github.com/owncloud/web/pull/13169
