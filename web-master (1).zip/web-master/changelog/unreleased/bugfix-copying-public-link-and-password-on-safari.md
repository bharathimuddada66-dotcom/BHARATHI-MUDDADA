Bugfix: Fix copying public link and password on Safari

We have fixed an issue where copying the public link and password on Safari was not working as expected.

https://kiteworks.atlassian.net/browse/OCISDEV-196
https://github.com/owncloud/web/pull/13177
