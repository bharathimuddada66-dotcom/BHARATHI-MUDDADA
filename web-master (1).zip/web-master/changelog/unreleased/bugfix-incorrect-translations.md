Bugfix: Fix incorrect translations

We have fixed an issue where translations were always showing in English, regardless of the user's selected language.

https://kiteworks.atlassian.net/browse/OCISDEV-420
https://github.com/owncloud/web/pull/13198
