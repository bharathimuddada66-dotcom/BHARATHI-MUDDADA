Enhancement: Hide trashed spaces

If the `root.deleted.state` property of a space is `trashed`, the space is not shown in the UI.
This includes also personal spaces.

https://github.com/owncloud/web/pull/13168
