Change: Customizable menu association

We now allow the redirect navItems and links into the user menu. This can be done by simply assigning the `"menu": "user"` to the respective navItem. It works for both extensions and external links (`applications` key in config.json).

https://github.com/owncloud/web/pull/4133
