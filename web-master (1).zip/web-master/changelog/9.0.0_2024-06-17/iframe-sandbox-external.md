Bugfix: Apply sandbox attribute to iframe in app-external extension

General hardening of ownCloud Web integration with OnlyOffice/Collabora

https://github.com/owncloud/web/pull/10706
