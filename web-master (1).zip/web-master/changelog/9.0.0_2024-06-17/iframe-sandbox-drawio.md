Bugfix: Apply sandbox attribute to iframe in draw-io extension

General hardening of ownCloud Web integration with draw.io

https://github.com/owncloud/web/pull/10702
